export async function GET(request: any) {
  return new Response('hello!');
}
