export default function Example() {
  return <h1>안녕아녕</h1>;
}
